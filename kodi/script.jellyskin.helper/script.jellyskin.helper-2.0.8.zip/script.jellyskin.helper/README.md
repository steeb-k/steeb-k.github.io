## Jellyskin Helper

For more information please [visit the wiki](https://github.com/sualfred/script.jellyskin.helper/wiki)